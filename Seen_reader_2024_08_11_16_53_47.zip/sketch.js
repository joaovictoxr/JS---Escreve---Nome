function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function setup() {
  createCanvas(400, 400);
}

// Crie um array de círculos
let circles = [];

function draw() {
  background(220);

  // Adicione um novo círculo ao array a cada clique do mouse
  if (mouseIsPressed) {
    let circle = {
      x: mouseX,
      y: mouseY,
      radius: random(10, 50),
      color: color(random(255), random(255), random(255))
    };
    circles.push(circle);
  }

  // Exiba todos os círculos do array
  for (let i = 0; i < circles.length; i++) {
    fill(circles[i].color);
    ellipse(circles[i].x, circles[i].y, circles[i].radius * 2);
  }
}